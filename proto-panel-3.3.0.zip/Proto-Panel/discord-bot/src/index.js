// PROTO HOSTING BOT — entry point
// Wires Discord client + SQLite + Petro Panel + invite tracking + admin API.
// Event handlers live in src/events/*, background jobs in src/jobs/*.
import {
  Client,
  GatewayIntentBits,
  Partials,
} from "discord.js";
import { loadConfig, validateConfig } from "./config/config.js";
import { createLogger } from "./utils/logger.js";
import { openDatabase } from "./database/database.js";
import { PetroAPI } from "./services/petroService.js";
import { InviteService } from "./services/inviteService.js";
import * as embeds from "./embeds/builders.js";
import { makeDispatcher } from "./dispatcher.js";
import { RateLimiter } from "./utils/rateLimit.js";
import { startAdminApi } from "./api/server.js";

import helpCommand from "./commands/help.js";
import registerCommand from "./commands/register.js";
import deployCommand from "./commands/deploy.js";
import invitesCommand from "./commands/invites.js";
import profileCommand from "./commands/profile.js";
import { serversCommand, serverCommand } from "./commands/servers.js";
import adminCommand from "./commands/admin/index.js";

import { registerReadyEvent } from "./events/ready.js";
import { registerMessageCreateEvent } from "./events/messageCreate.js";
import { registerInteractionCreateEvent } from "./events/interactionCreate.js";
import { registerGuildMemberAddEvent } from "./events/guildMemberAdd.js";
import { registerGuildMemberRemoveEvent } from "./events/guildMemberRemove.js";
import { registerInviteSyncEvents } from "./events/inviteSync.js";

// ---------------------------------------------------------------- bootstrapping
const cfg = loadConfig();
const logger = createLogger(cfg);

if (!cfg.testMode) {
  const problems = validateConfig(cfg);
  for (const problem of problems) {
    logger.warn(`config: ${problem}`);
  }
  if (!cfg.token) {
    console.error(
      [
        "",
        "==========================================================",
        " PROTO HOSTING BOT — cannot start",
        "==========================================================",
        " DISCORD_BOT_TOKEN is missing.",
        "  1. copy discord-bot/.env.example to discord-bot/.env",
        "  2. fill in DISCORD_BOT_TOKEN, BOT_OWNER_IDS,",
        "     PETRO_PANEL_URL and PETRO_APP_KEY",
        "  3. start again:  npm start",
        "==========================================================",
        "",
      ].join("\n")
    );
    process.exit(1);
  }
}

const db = openDatabase(cfg.dbPath);
logger.info(`database ready at ${cfg.dbPath}`);

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMembers, // privileged — enable in the developer portal
    GatewayIntentBits.GuildInvites,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent, // privileged — enable in the developer portal
    GatewayIntentBits.DirectMessages,
  ],
  partials: [Partials.Channel, Partials.Message],
});

const petro = new PetroAPI(cfg.petro, logger);
const invites = new InviteService(db, client, logger);

const ctx = {
  cfg,
  db,
  client,
  logger,
  petro,
  invites,
  embeds, // branded builders for jobs/services that send DMs
  jobs: [], // background job timers, cleared on shutdown
  startedAt: Date.now(),
};

const registry = [
  helpCommand,
  registerCommand,
  deployCommand,
  invitesCommand,
  profileCommand,
  serversCommand,
  serverCommand,
  adminCommand,
];

const { dispatchMessage, dispatchInteraction } = makeDispatcher(registry, {
  limiter: new RateLimiter(cfg.rateLimit),
});
// exposed on ctx so src/events/* can route through the same pipeline
ctx._dispatchMessage = dispatchMessage;
ctx._dispatchInteraction = dispatchInteraction;

// ---------------------------------------------------------------- events
registerMessageCreateEvent(ctx);
registerInteractionCreateEvent(ctx);
registerGuildMemberAddEvent(ctx);
registerGuildMemberRemoveEvent(ctx);
registerInviteSyncEvents(ctx);
registerReadyEvent(ctx); // starts background jobs once ready

// admin API (panel integration)
let apiServer = null;
if (cfg.api.enabled) {
  apiServer = startAdminApi(ctx);
}

function shutdown(signal) {
  logger.info(`${signal} received — shutting down`);
  try {
    for (const timer of ctx.jobs) clearInterval(timer);
    if (apiServer) apiServer.close();
    client.destroy();
  } catch {
    /* ignore */
  }
  try {
    db.close();
  } catch {
    /* ignore */
  }
  process.exit(0);
}
process.on("SIGINT", () => shutdown("SIGINT"));
process.on("SIGTERM", () => shutdown("SIGTERM"));

process.on("unhandledRejection", (reason) => {
  logger.error(`unhandled rejection: ${reason?.stack || reason}`);
});

// test mode exports the wired context instead of logging in
if (cfg.testMode) {
  logger.info("PROTO_BOT_TEST=1 — test mode, Discord login skipped");
} else {
  client.login(cfg.token).catch((err) => {
    console.error(`login failed: ${err.message}`);
    console.error("Check DISCORD_BOT_TOKEN in discord-bot/.env");
    process.exit(1);
  });
}

export { ctx, registry, client, dispatchMessage, dispatchInteraction };
