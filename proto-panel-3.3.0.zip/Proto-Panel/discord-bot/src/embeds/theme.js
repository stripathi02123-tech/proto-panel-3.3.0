// PROTO HOSTING BOT — centralized theme configuration
// Single source of truth for ALL branding: colors, emojis, names, footers.
// Every embed builder imports from here, so the entire bot can be re-skinned
// by editing this one file. No command hardcodes a color or brand string.
import { EmbedBuilder } from "discord.js";

export const THEME = {
  brand: {
    name: "PROTO HOSTING",
    product: "PROTO PANEL",
    footer: "PROTO PANEL · Discord Hosting",
    tagline: "Premium Discord bot hosting — real invites unlock real servers.",
  },
  colors: {
    brand: 0x3b82f6, // electric blue — primary actions & info
    cyan: 0x22d3ee, // cyan highlight — server cards
    success: 0x34d399, // green — success states
    error: 0xef4444, // red — errors / denied
    warn: 0xf59e0b, // amber — warnings & confirmations
    purple: 0x8b5cf6, // purple accent — brand highlights
    dark: 0x0b1020, // deep midnight background tone
    muted: 0x64748b, // slate — cancelled / neutral states
  },
  emoji: {
    success: "✅",
    error: "⛔",
    warn: "⚠️",
    loading: "⏳",
    idle: "▫️",
    rocket: "🚀",
    server: "🖥️",
    package: "📦",
    invites: "📨",
    crown: "👑",
    gear: "🛠️",
    user: "🧬",
    chart: "📊",
    lock: "🔒",
    cancel: "🚫",
    trash: "🗑️",
    refresh: "♻️",
    party: "🎉",
    console: "📺",
  },
};

// Backwards-compatible alias (builders previously exported COLORS directly).
export const COLORS = THEME.colors;

/** Apply the shared footer/timestamp to any embed. */
export function applyBrand(eb) {
  return eb
    .setFooter({ text: THEME.brand.footer })
    .setTimestamp(new Date());
}

/** Base factory used by every builder in builders.js. */
export function themedEmbed({ title, description, color }) {
  const eb = new EmbedBuilder().setColor(color ?? THEME.colors.brand);
  applyBrand(eb);
  if (title) eb.setTitle(title);
  if (description) eb.setDescription(description);
  return eb;
}
