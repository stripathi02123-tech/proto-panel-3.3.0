// PROTO HOSTING BOT — guildMemberAdd event
// Attribute the join to a REAL invite code by diffing the guild's invite
// snapshot before/after the join. Vanity-URL joins cannot be attributed and
// are recorded uncredited. Bots never count.
import { Events } from "discord.js";

export async function onGuildMemberAdd(ctx, member) {
  try {
    const inviterId = await ctx.invites.onMemberAdd(member);
    if (inviterId) ctx.logger.info(`join: ${member.user?.tag} via invite of ${inviterId}`);
  } catch (err) {
    ctx.logger.error(`guildMemberAdd failed: ${err.message}`);
  }
}

export function registerGuildMemberAddEvent(ctx) {
  ctx.client.on(Events.GuildMemberAdd, (member) => onGuildMemberAdd(ctx, member));
}
