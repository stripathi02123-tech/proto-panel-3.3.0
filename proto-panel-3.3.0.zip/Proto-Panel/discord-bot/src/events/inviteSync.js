// PROTO HOSTING BOT — invite create/delete events
// Any invite change re-syncs the guild snapshot so deleted invites are marked
// revoked and new codes are tracked from their first use.
import { Events } from "discord.js";

async function resync(ctx, guild, what) {
  try {
    await ctx.invites.snapshotGuild(guild);
  } catch (err) {
    ctx.logger.error(`${what} sync failed: ${err.message}`);
  }
}

export function registerInviteSyncEvents(ctx) {
  ctx.client.on(Events.InviteCreate, (invite) => resync(ctx, invite.guild, "inviteCreate"));
  ctx.client.on(Events.InviteDelete, (invite) => resync(ctx, invite.guild, "inviteDelete"));
}
