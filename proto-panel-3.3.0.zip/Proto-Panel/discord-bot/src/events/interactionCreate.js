// PROTO HOSTING BOT — interactionCreate event
// Buttons + select menus. The dispatcher validates that components are
// personal (custom ids embed the owner's Discord id) before acting.
import { Events } from "discord.js";

export function onInteractionCreate(ctx, interaction) {
  return ctx._dispatchInteraction(ctx, interaction);
}

export function registerInteractionCreateEvent(ctx) {
  ctx.client.on(Events.InteractionCreate, (interaction) => {
    onInteractionCreate(ctx, interaction).catch((err) =>
      ctx.logger.error(`interactionCreate dispatch failed: ${err?.stack || err}`)
    );
  });
}
