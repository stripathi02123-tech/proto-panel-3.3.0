// PROTO HOSTING BOT — !profile
// Personal hosting dashboard: account, invites, servers, resources and the
// plans the user is currently eligible for — all real data, nothing invented.
import { MessageFlags } from "discord.js";
import { infoEmbed, fmtCpu, fmtMem, fmtDisk, runtimeLabel } from "../embeds/builders.js";
import { listPlans } from "../services/plans.js";
import { countOwnServers } from "../services/serverService.js";

export default {
  name: "profile",
  aliases: ["me", "account"],
  description: "Your hosting account overview",
  usage: "!profile",

  async handle(ctx, message) {
    const discordId = String(message.author.id);
    const user = ctx.db.prepare("SELECT * FROM users WHERE discord_id = ?").get(discordId);

    if (!user) {
      const eb = infoEmbed(
        "🧬 No hosting account yet",
        "You are not registered.\nRun **`!register`** — one account per Discord user, credentials are sent via DM."
      );
      await message.reply({ embeds: [eb], flags: MessageFlags.Ephemeral });
      return;
    }

    const guildId = message.guild?.id ?? null;
    const stats = ctx.invites.statsFor(discordId, guildId);
    const serverCount = countOwnServers(ctx.db, discordId);
    const link = ctx.db.prepare("SELECT * FROM petro_accounts WHERE user_id = ?").get(user.id);

    // resources actually in use across the user's live servers
    const usage = ctx.db
      .prepare(
        `SELECT COALESCE(SUM(p.cpu), 0) AS cpu, COALESCE(SUM(p.memory), 0) AS memory, COALESCE(SUM(p.disk), 0) AS disk
         FROM servers s LEFT JOIN plans p ON p.id = s.plan_id
         WHERE s.owner_discord_id = ? AND s.deleted_at IS NULL`
      )
      .get(discordId);

    // plans the user can deploy RIGHT NOW (available + enough valid invites)
    const plans = listPlans(ctx.db, { availableOnly: true });
    const eligible = plans.filter((p) => stats.valid >= p.required_invites);
    const next = plans
      .filter((p) => stats.valid < p.required_invites)
      .sort((a, b) => a.required_invites - b.required_invites)[0];

    const eb = infoEmbed(
      `🧬 ${user.username}'s hosting profile`,
      `Account **${user.account_id}** · status: \`${user.status}\``
    );
    eb.addFields(
      { name: "Account ID", value: `\`${user.account_id}\``, inline: true },
      { name: "Panel email", value: `\`${user.email}\``, inline: true },
      { name: "Registered", value: `${user.created_at?.replace("T", " ").slice(0, 10) || "—"} UTC`, inline: true },
      { name: "📨 Valid invites", value: String(stats.valid), inline: true },
      { name: "⏳ Pending", value: String(stats.pending), inline: true },
      { name: "👋 Departed", value: String(stats.departed), inline: true },
      { name: "🖥️ Servers", value: `${serverCount} / ${ctx.cfg.serverLimitPerUser}`, inline: true },
      { name: "Panel user", value: link ? `\`${link.petro_user_id}\`` : "*missing — will self-heal on next deploy*", inline: true },
      { name: "Linked", value: link?.existed ? "existing panel account" : "created by bot", inline: true },
      {
        name: "Resources in use",
        value: `${fmtCpu(usage.cpu)} CPU · ${fmtMem(usage.memory)} RAM · ${fmtDisk(usage.disk)} disk`,
      }
    );
    if (eligible.length > 0) {
      eb.addFields({
        name: "✅ Plans you can deploy now",
        value: eligible
          .slice(0, 10)
          .map((p) => `**${p.name}** (${runtimeLabel(p.runtime)}) — ${fmtCpu(p.cpu)}, ${fmtMem(p.memory)}, ${fmtDisk(p.disk)}`)
          .join("\n"),
      });
    }
    if (next) {
      eb.addFields({
        name: "🎯 Next unlock",
        value: `**${next.name}** needs **${next.required_invites}** valid invites — you have **${stats.valid}** (**${Math.max(0, next.required_invites - stats.valid)}** to go).`,
      });
    }
    if (user.status !== "active") {
      eb.setColor(0xef4444);
      eb.addFields({
        name: "⛔ Account suspended",
        value: "Deployments and server management are blocked. Contact an administrator.",
      });
    }
    await message.reply({ embeds: [eb], flags: MessageFlags.Ephemeral });
  },
};
