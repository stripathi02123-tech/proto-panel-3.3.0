// PROTO HOSTING BOT — server service
// Ownership-checked server lookup + paginated listings. Every helper here
// takes the Discord id and ONLY ever returns rows owned by that user
// (anti-IDOR at the data layer, not just in the command layer).
export const SERVERS_PER_PAGE = 5;

/**
 * Find ONE of the user's own servers by name or #id.
 * Returns null for anything the user does not own — indistinguishable from
 * "does not exist", so ownership cannot be probed.
 */
export function findOwnServer(db, discordId, query) {
  const q = String(query || "").trim();
  if (!q) return null;
  if (q.startsWith("#")) {
    return db
      .prepare("SELECT * FROM servers WHERE owner_discord_id = ? AND deleted_at IS NULL AND id = ?")
      .get(String(discordId), parseInt(q.slice(1), 10) || 0);
  }
  return db
    .prepare(
      "SELECT * FROM servers WHERE owner_discord_id = ? AND deleted_at IS NULL AND LOWER(name) = LOWER(?)"
    )
    .get(String(discordId), q);
}

/** Count of a user's active (non-deleted) servers. */
export function countOwnServers(db, discordId) {
  return db
    .prepare("SELECT COUNT(*) AS c FROM servers WHERE owner_discord_id = ? AND deleted_at IS NULL")
    .get(String(discordId)).c;
}

/**
 * One page of the user's servers, newest first.
 * @returns {{ rows: object[], page: number, totalPages: number, total: number }}
 */
export function listServersPage(db, discordId, page = 1, perPage = SERVERS_PER_PAGE) {
  const total = countOwnServers(db, discordId);
  const totalPages = Math.max(1, Math.ceil(total / perPage));
  const p = Math.min(Math.max(1, parseInt(page, 10) || 1), totalPages);
  const rows = db
    .prepare(
      `SELECT * FROM servers WHERE owner_discord_id = ? AND deleted_at IS NULL
       ORDER BY id DESC LIMIT ? OFFSET ?`
    )
    .all(String(discordId), perPage, (p - 1) * perPage);
  return { rows, page: p, totalPages, total };
}
