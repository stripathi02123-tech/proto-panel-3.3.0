// PROTO HOSTING BOT — plan configuration
// The DATABASE is the single source of truth for plans: admins edit them live
// with !admin plan create|edit|delete (or via the panel's Bot Hosting page).
// This module only defines the VALIDATION BOUNDS shared by the Discord admin
// command and the admin HTTP API, plus the reference defaults used when a
// brand-new database is seeded by migration 001.

export const PLAN_LIMITS = {
  cpu: { min: 25, max: 800, unit: "%" },
  memory: { min: 128, max: 32768, unit: "MiB" },
  disk: { min: 256, max: 262144, unit: "MiB" },
  required_invites: { min: 0, max: 100000, unit: "invites" },
  sort_order: { min: 0, max: 9999, unit: "" },
};

export const RUNTIMES = ["node.js", "python"];

/** Reference seed tiers (mirrors migration 001 — documentation + fresh installs). */
export const DEFAULT_PLANS = [
  { name: "Micro",   runtime: "node.js", cpu: 50,  memory: 512,  disk: 1024,  required_invites: 1, available: 1, description: "Entry tier — needs 1 valid invite", sort_order: 10 },
  { name: "Starter", runtime: "node.js", cpu: 100, memory: 1024, disk: 4096,  required_invites: 3, available: 1, description: "Most popular tier", sort_order: 20 },
  { name: "Pro",     runtime: "node.js", cpu: 200, memory: 2048, disk: 10240, required_invites: 6, available: 1, description: "Power tier for busy bots", sort_order: 30 },
  { name: "Micro",   runtime: "python",  cpu: 50,  memory: 512,  disk: 1024,  required_invites: 1, available: 1, description: "Entry tier — needs 1 valid invite", sort_order: 10 },
  { name: "Starter", runtime: "python",  cpu: 100, memory: 1024, disk: 4096,  required_invites: 3, available: 1, description: "Most popular tier", sort_order: 20 },
  { name: "Pro",     runtime: "python",  cpu: 200, memory: 2048, disk: 10240, required_invites: 6, available: 1, description: "Power tier for busy bots", sort_order: 30 },
];

/** Normalize runtime aliases to canonical ids. */
export function normalizeRuntime(input) {
  const v = String(input || "").trim().toLowerCase();
  if (["node.js", "nodejs", "node", "js", "javascript"].includes(v)) return "node.js";
  if (["python", "python3", "py"].includes(v)) return "python";
  return null;
}
