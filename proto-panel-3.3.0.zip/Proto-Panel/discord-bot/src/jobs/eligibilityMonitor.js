// PROTO HOSTING BOT — eligibility monitor job
// Watches plans a user WANTED but couldn't deploy yet (invite requirement
// not completed). When their verified invite count rises to meet the plan,
// they get a one-time DM. Rows expire after 30 days to stay honest.

const MAX_DMS_PER_SWEEP = 20; // don't melt Discord rate limits
const WATCH_TTL_DAYS = 30;

/** Record that `discordId` wanted `planId` but lacked invites (idempotent). */
export function watchPlanForUser(db, discordId, planId, guildId = null) {
  try {
    db.prepare(
      `INSERT INTO eligibility_watch (discord_id, plan_id, guild_id) VALUES (?, ?, ?)
       ON CONFLICT(discord_id, plan_id) DO UPDATE SET guild_id = excluded.guild_id`
    ).run(String(discordId), parseInt(planId, 10), guildId ? String(guildId) : null);
  } catch {
    /* watching must never break a command */
  }
}

/**
 * One monitoring pass.
 * @param {object} ctx
 * @param {object} [opts]
 * @param {Function} [opts.dm]  async (discordId, embed) => void — injectable for tests
 * @returns {number} users notified this pass
 */
export async function runEligibilitySweep(ctx, { dm } = {}) {
  const sendDm =
    dm ||
    (async (discordId, embed) => {
      const user = await ctx.client.users.fetch(discordId);
      await user.send({ embeds: [embed.toJSON()] });
    });

  const rows = ctx.db
    .prepare(
      `SELECT w.id AS watch_id, w.discord_id, w.guild_id, w.notified_at,
              p.id AS plan_id, p.name AS plan_name, p.runtime, p.cpu, p.memory, p.disk, p.required_invites
       FROM eligibility_watch w
       JOIN plans p ON p.id = w.plan_id
       JOIN users u ON u.discord_id = w.discord_id
       WHERE w.notified_at IS NULL AND p.available = 1 AND u.status = 'active'
       ORDER BY w.id
       LIMIT ?`
    )
    .all(500);

  let notified = 0;
  for (const row of rows) {
    if (notified >= MAX_DMS_PER_SWEEP) break;
    try {
      const stats = ctx.invites.statsFor(row.discord_id, row.guild_id);
      if (stats.valid < row.required_invites) continue;

      const embed = ctx.embeds.eligibilityReachedEmbed(row, stats);
      await sendDm(row.discord_id, embed);
      ctx.db.prepare("UPDATE eligibility_watch SET notified_at = datetime('now') WHERE id = ?").run(row.watch_id);
      ctx.logger.info(`eligibility: ${row.discord_id} now meets ${row.plan_name} (${row.required_invites} invites) — notified`);
      notified++;
    } catch (err) {
      // DM failed (closed DMs / unknown user) — mark notified so we don't retry forever
      ctx.db.prepare("UPDATE eligibility_watch SET notified_at = datetime('now') WHERE id = ?").run(row.watch_id);
      ctx.logger.warn(`eligibility DM failed for ${row.discord_id}: ${err.message}`);
    }
  }

  // expire stale watches
  ctx.db
    .prepare(`DELETE FROM eligibility_watch WHERE created_at < datetime('now', '-${WATCH_TTL_DAYS} days')`)
    .run();

  return notified;
}

export function startEligibilityMonitor(ctx) {
  const minutes = Math.max(5, ctx.cfg.jobs.eligibilityMinutes);
  const timer = setInterval(() => {
    runEligibilitySweep(ctx).catch((err) =>
      ctx.logger.error(`eligibility sweep failed: ${err.message}`)
    );
  }, minutes * 60 * 1000);
  if (typeof timer.unref === "function") timer.unref();
  ctx.logger.info(`eligibility monitor job scheduled (every ${minutes} min)`);
  return timer;
}
