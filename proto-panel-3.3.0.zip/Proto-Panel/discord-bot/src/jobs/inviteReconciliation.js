// PROTO HOSTING BOT — invite reconciliation job
// Periodic repair pass (default every 10 minutes):
//   · refreshes invite snapshots (catches deleted/edited invites)
//   · closes joins for members that left while the bot was offline
//   · repairs attribution drift after restarts
// Never assumes invite usage alone proves a member is still present —
// actual guild membership is re-enumerated for guilds ≤ 1000 members.

export function startInviteReconciliation(ctx) {
  const minutes = Math.max(1, ctx.cfg.jobs.reconcileMinutes);
  const timer = setInterval(() => {
    ctx.invites
      .reconcile()
      .catch((err) => ctx.logger.error(`reconcile failed: ${err.message}`));
  }, minutes * 60 * 1000);
  if (typeof timer.unref === "function") timer.unref();
  ctx.logger.info(`invite reconciliation job scheduled (every ${minutes} min)`);
  return timer;
}

/** Run one reconciliation pass right now (used by tests and manual triggers). */
export async function reconcileOnce(ctx) {
  return ctx.invites.reconcile();
}
