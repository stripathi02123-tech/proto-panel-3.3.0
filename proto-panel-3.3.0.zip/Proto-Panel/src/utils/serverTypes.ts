/**
 * Canonical display helpers for server software types.
 *
 * The backend stores a raw type id on every server record
 * ("paper", "nodejs", "python", "velocity", ...). These helpers turn it
 * into a clean human label so cards, tables and dashboards never fall back
 * to a wrong default like "minecraft" for a Python server.
 */
const GAME_LABELS: Record<string, string> = {
  paper: "Paper",
  purpur: "Purpur",
  spigot: "Spigot",
  bukkit: "Bukkit",
  fabric: "Fabric",
  forge: "Forge",
  neoforge: "NeoForge",
  quilt: "Quilt",
  vanilla: "Vanilla",
  velocity: "Velocity",
  waterfall: "Waterfall",
  bungeecord: "BungeeCord",
  nodejs: "Node.js",
  node: "Node.js",
  python: "Python",
  python3: "Python",
};

/** "paper" -> "Paper", "nodejs" -> "Node.js", unknown -> Capitalized, empty -> "Server" */
export function gameLabel(type?: string | null): string {
  const key = (type || "").trim().toLowerCase();
  if (!key) return "Server";
  if (GAME_LABELS[key]) return GAME_LABELS[key];
  return key.charAt(0).toUpperCase() + key.slice(1);
}

/** Version suffix: Node runtimes render "v22", everything else keeps the raw version. */
export function versionLabel(type?: string | null, version?: string | null): string {
  const v = (version || "").trim();
  if (!v) return "";
  const key = (type || "").trim().toLowerCase();
  if (key === "nodejs" || key === "node") return `v${v}`;
  return v;
}
