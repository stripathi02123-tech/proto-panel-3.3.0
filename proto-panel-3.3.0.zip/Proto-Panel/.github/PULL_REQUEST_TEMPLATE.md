## What does this PR do?
<!-- A short summary of the change. Reference the issue it closes, e.g. "Closes #123". -->

## Type of change
- [ ] 🐛 Bug fix (non-breaking change that fixes an issue)
- [ ] ✨ New feature (non-breaking change that adds functionality)
- [ ] 💥 Breaking change (fix or feature that would cause existing functionality to change)
- [ ] 📚 Documentation update
- [ ] 🔒 Security hardening

## Checklist
- [ ] I ran `npm run lint` (tsc --noEmit) and it passes
- [ ] I ran `npm run build` and it succeeds
- [ ] I tested the change locally (dev or production build)
- [ ] New/changed endpoints enforce proper authorization (owner/admin/user)
- [ ] No secrets, tokens or passwords are committed

## Screenshots
<!-- For UI changes, add before/after screenshots. -->
